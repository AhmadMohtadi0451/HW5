let a =3
let b = 4
let c = 5
if(a**2 + b**2 == c**2) {
    console.log("yes");
}
else{
    console.log("no");
}