let height = 1.80
let weight = 60
let bmi=weight / (height**2)
if (bmi < 18.5){
    console.log("underweight");
}
else if(bmi>=18.5 && bmi<25){
    console.log("normal");
}
else if(bmi>=25 && bmi<30){
    console.log("overweight");
}
else if (bmi>=30){
    console.log("obssene");
}
