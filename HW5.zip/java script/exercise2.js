let number = 27
let divisors = []
for(let i = 1 ; i <number/2 + 1 ; i++){
    if(number % i ==0 ){
        divisors.push(i)
    }
    
}
console.log(divisors);
let x = 0
for ( i = 0; i<divisors.length; i++){
    x += divisors[i]
}
if(x == number){
    console.log("yes");
} else{
    console.log("no");
}