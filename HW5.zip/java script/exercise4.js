function personalData(firstName, lastName, age , emailAdress,  phoneNumber , gender){
    let person = {
        firstName : "",
        lastName : "",
        age : "",
        emailAdress:"",
        phoneNumber:"",
        gender:""
    };
    person.firstName=firstName;
    person.emailAdress=emailAdress
    person.lastName=lastName
    person.age=age
    person.phoneNumber=phoneNumber
    person.gender=gender
    console.log(person);
};
personalData("soheil" , "saedi" , 20, "soheilsaedi1379@gmail.com","09197166404","male")
