let number = 101
for (let i = 0 ; i<number; i++){
    if(i**2>number){
        console.log(i);
        break
    } 
}
