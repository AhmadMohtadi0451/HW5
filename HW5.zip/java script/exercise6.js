let x = 14
let y  = 0
if( y ==0){
    console.log(20);
}
else if(y == 7){
    console.log(x);
}
else if ( y > x ){
    console.log(0);
}else{
    console.log(x-y);
}